const accessCode1 = "VARIABLE";
const accessCode2 = "FUNCTION";
const accessCode3 = "DATABASE";

function clues() {
    
    fill("white")
    textSize(15)
    text("R E V B A I L A", 100,50)
    fill("lightblue")
    text("Hint: Always changing, not constant !!", 100,70)

    fill("white")
    textSize(15)
    text("C U T N I F O N", 700,150)
    fill("lightblue")
    text("Hint: Performs a particular task !!", 700,170)

    fill("white")
    textSize(15)
    text("A T E D A S B A", 100,250)
    fill("lightblue")
    text("Hint: Stores all information !!", 100,270)

}